<?php ?>
<div class="checkout-loader"> 
    <div class="loader-center">
        <p class="loader-text">Loading Checkout</p>
        <div class="progress-loader"></div>
    </div>
</div>